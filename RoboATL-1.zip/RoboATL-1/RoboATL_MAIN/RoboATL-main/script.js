// ----------------- Mobile Nav -----------------
const mobileToggle = document.getElementById('mobileToggle');
const navLinks = document.getElementById('navLinks');

mobileToggle.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Close menu when clicking a link
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
    });
});

// ----------------- Main Slider -----------------
let mainCurrent = 0;
const mainSlider = document.getElementById('slider');
let mainSlides = document.querySelectorAll('.slide');
let mainTotal = mainSlides.length;
const mainPrev = document.querySelector('.nav-button.prev');
const mainNext = document.querySelector('.nav-button.next');

let autoSlideTimer;
const autoSlideDelay = 3000; // 3 seconds
// Testimonial slider state (declare early to avoid undefined errors)
let testSlides = [];
let testIndicators = [];
let testCurrent = 0;
let testAutoTimer;

function updateMainSlider() {
    mainSlider.style.transform = `translateX(-${mainCurrent * 100}%)`;

    mainSlides.forEach((slide, i) => {
        slide.classList.toggle('active', i === mainCurrent);
    });

    mainPrev.disabled = mainCurrent === 0;
    mainNext.disabled = mainCurrent === mainTotal - 1;
    // Adjust wrapper height to match active slide content so slider adapts to varying content heights
    adjustMainSliderHeight();
}

function adjustMainSliderHeight() {
    // mainWrapper refers to .slider-wrapper containing the .slider
    if (!mainWrapper) return;
    // Find the active slide
    const active = mainSlides && mainSlides.length ? Array.from(mainSlides).find(s => s.classList.contains('active')) : null;
    if (!active) return;
    // Measure its height and apply to wrapper with a smooth transition
    const h = active.offsetHeight;
    mainWrapper.style.transition = 'height 0.35s ease';
    mainWrapper.style.height = h + 'px';
}

function changeMainSlide(dir) {
    let newIndex = mainCurrent + dir;

    if (newIndex >= mainTotal) {
        newIndex = 0;
    } else if (newIndex < 0) {
        newIndex = mainTotal - 1;
    }

    mainCurrent = newIndex;
    updateMainSlider();
    resetMainAuto();
}

// Auto slide
function startMainAuto() {
    autoSlideTimer = setInterval(() => {
        changeMainSlide(1);
    }, autoSlideDelay);
}

function resetMainAuto() {
    clearInterval(autoSlideTimer);
    startMainAuto();
}

// Buttons
if (mainPrev) mainPrev.addEventListener('click', () => changeMainSlide(-1));
if (mainNext) mainNext.addEventListener('click', () => changeMainSlide(1));

// Keyboard
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowLeft') changeMainSlide(-1);
    if (e.key === 'ArrowRight') changeMainSlide(1);
});

// Touch/Swipe
let mainTouchStart = 0;
let mainTouchEnd = 0;
const mainWrapper = document.querySelector('.slider-wrapper');

mainWrapper.addEventListener('touchstart', (e) => {
    mainTouchStart = e.changedTouches[0].screenX;
});
mainWrapper.addEventListener('touchend', (e) => {
    mainTouchEnd = e.changedTouches[0].screenX;
    handleMainSwipe();
});

// Recalculate slider height on window resize to adapt to responsive layout
window.addEventListener('resize', () => {
    // small debounce
    clearTimeout(window._adjustSliderTimeout);
    window._adjustSliderTimeout = setTimeout(() => adjustMainSliderHeight(), 120);
});

function handleMainSwipe() {
    const diff = mainTouchStart - mainTouchEnd;
    if (Math.abs(diff) > 50) {
        if (diff > 0) changeMainSlide(1);
        else changeMainSlide(-1);
    }
}

// Indicator clicks (only if indicators exist)
if (testIndicators && testIndicators.length) {
    testIndicators.forEach((ind, i) => {
        ind.addEventListener('click', () => goToTestSlide(i));
    });
}

// Auto play
function startTestAuto() {
    if (!testSlides || testSlides.length === 0) return;
    testAutoTimer = setInterval(() => {
        goToTestSlide((testCurrent + 1) % testSlides.length);
    }, 5000);
}
function stopTestAuto() {
    clearInterval(testAutoTimer);
}

// Hover pause (only if testimonial container exists)
const testContainer = document.querySelector('.slider-container-tests');
if (testContainer) {
    testContainer.addEventListener('mouseenter', stopTestAuto);
    testContainer.addEventListener('mouseleave', startTestAuto);
}

// Touch/Swipe
let testTouchStart = 0;
let testTouchEnd = 0;

if (testContainer) {
    testContainer.addEventListener('touchstart', (e) => {
        testTouchStart = e.changedTouches[0].screenX;
        stopTestAuto();
    });
    testContainer.addEventListener('touchend', (e) => {
        testTouchEnd = e.changedTouches[0].screenX;
        handleTestSwipe();
        startTestAuto();
    });
}

function handleTestSwipe() {
    const diff = testTouchStart - testTouchEnd;
    if (Math.abs(diff) > 50) {
        if (diff > 0) goToTestSlide((testCurrent + 1) % testSlides.length);
        else goToTestSlide((testCurrent - 1 + testSlides.length) % testSlides.length);
    }
}

// Testimonial auto-start moved to frontend init after loading data

const floatingIcon = document.getElementById('floatingIcon');
const iconBtn = document.getElementById('iconBtn');
const modalOverlay = document.getElementById('modalOverlay');
const navbar = document.querySelector('nav');
if (floatingIcon && iconBtn && modalOverlay && navbar) {
    // Show/hide floating icon based on scroll
    window.addEventListener('scroll', () => {
        const navbarHeight = navbar.offsetHeight;
        if (window.scrollY > navbarHeight) {
            floatingIcon.classList.add('visible');
        } else {
            floatingIcon.classList.remove('visible');
        }
    });

    // Open modal
    iconBtn.addEventListener('click', () => {
        modalOverlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    });

    // Close modal
    function closeModal() {
        modalOverlay.classList.remove('active');
        document.body.style.overflow = 'auto';
    }

    // Close modal when clicking overlay
    modalOverlay.addEventListener('click', (e) => {
        if (e.target === modalOverlay) closeModal();
    });

    // Download handler
    function handleDownload() {
        alert('Redirecting to download page...');
        // Add your download link here
        // window.location.href = 'your-download-link';
    }

    // Close modal with Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && modalOverlay.classList.contains('active')) closeModal();
    });
}

// ----------------- Dynamic data loaders (load from backend APIs) -----------------
async function loadPrograms() {
        try {
                const res = await fetch('/api/programs');
                if (!res.ok) return;
                const programs = await res.json();
                if (!Array.isArray(programs) || programs.length === 0) return;
                mainSlider.innerHTML = programs.map(p => `
                        <div class="slide">
                            <div class="popular">
                                ${p.badge ? `<h6>${p.badge}</h6>` : ''}
                            </div>
                            <div class="head-content">
                                <h1 class="title">${p.title || ''}</h1>
                                <p class="subtitle">${p.level || ''} \u2022 ${Array.isArray(p.mode) ? p.mode.join(' / ') : (p.mode || '')}</p>
                            </div>
                            <div class="text-content">
                                <p class="description">${p.description || ''}</p>
                                ${Array.isArray(p.contents) && p.contents.length ? `<div class="program-meta"><strong>Contents:</strong><ul>${p.contents.map(c=>`<li>${c}</li>`).join('')}</ul></div>` : ''}
                                ${Array.isArray(p.outcomes) && p.outcomes.length ? `<div class="program-meta"><strong>Outcomes:</strong><ul>${p.outcomes.map(o=>`<li>${o}</li>`).join('')}</ul></div>` : ''}
                                ${Array.isArray(p.audience) && p.audience.length ? `<div class="program-meta"><strong>Audience:</strong> ${p.audience.join(', ')}</div>` : ''}
                                ${Array.isArray(p.syllabus) && p.syllabus.length ? `<div class="program-meta"><strong>Syllabus:</strong> ${p.syllabus.join(', ')}</div>` : ''}
                                <h4>Price - \u20b9${p.priceINR || ''}</h4>
                                <div class="buttons-container">
                                    <button class="button enroll-button">Enroll</button>
                                    <button class="button brochure-button">Brochure</button>
                                </div>
                            </div>
                            <div class="image">
                                <img src="${p.image || 'Assets/Images/program.jpeg'}" alt="">
                            </div>
                        </div>
                `).join('');
                mainSlides = document.querySelectorAll('.slide');
                mainTotal = mainSlides.length;
                if (mainCurrent >= mainTotal) mainCurrent = 0;
                updateMainSlider();
                // Ensure wrapper height matches content after we render slides
                // and also when images within slides finish loading
                adjustMainSliderHeight();
                mainSlides.forEach(sl => {
                    const imgs = sl.querySelectorAll('img');
                    imgs.forEach(img => {
                        if (!img.complete) {
                            img.addEventListener('load', () => adjustMainSliderHeight());
                            img.addEventListener('error', () => adjustMainSliderHeight());
                        }
                    });
                });
        } catch (e) { console.warn('loadPrograms failed', e); }
}

async function loadKits() {
        try {
                const res = await fetch('/api/kits');
                if (!res.ok) return;
                const kits = await res.json();
                const box = document.querySelector('.kitbox');
                if (!box || !Array.isArray(kits)) return;
                box.innerHTML = kits.map(k => {
                    const price = k.priceINR ? `\u20b9${k.priceINR}` : (k.priceRangeINR ? k.priceRangeINR : (k.price ? `\u20b9${k.price}` : 'Price not set'));
                    const contents = Array.isArray(k.contents) ? `<ul class="kit-contents">${k.contents.map(c=>`<li>${c}</li>`).join('')}</ul>` : '';
                    const img = k.image || (Array.isArray(k.images) && k.images[0]) || 'Assets/Images/program.jpeg';
                    return `
                        <div class="card">
                            <div>
                                <h1 class="kit-title">${k.name || ''}</h1>
                                ${contents}
                                <p class="kit-price">Price: ${price}</p>
                            </div>
                            <button class="button">Inquiry</button>
                        </div>
                    `;
                }).join('');
        } catch (e) { console.warn('loadKits failed', e); }
}

async function loadWebinars() {
        try {
                const res = await fetch('/api/webinars');
                if (!res.ok) return;
                const webinars = await res.json();
                const wc = document.querySelector('.webinar-cards');
                if (!wc || !Array.isArray(webinars)) return;
                wc.innerHTML = `${webinars.map(w => {
                    // choose date field (dateISO preferred)
                    const dateVal = w.dateISO || w.date || '';
                    let dateStr = '';
                    try { if (dateVal) dateStr = new Date(dateVal).toLocaleString(); } catch (e) { dateStr = dateVal; }
                    const level = w.level || w.difficulty || '';
                    const seats = w.seats ? `Seats: ${w.seats}` : '';
                    const paid = (typeof w.paid !== 'undefined') ? (w.paid ? (w.priceINR ? `Price: \u20b9${w.priceINR}` : 'Paid') : 'Free') : (w.priceINR ? `Price: \u20b9${w.priceINR}` : '');
                    // description may be stored as comma-separated values
                    let desc = '';
                    if (Array.isArray(w.description)) desc = w.description.join(', ');
                    else if (w.description) desc = w.description;
                    else if (Array.isArray(w.tags)) desc = w.tags.join(', ');
                    else if (w.topics) desc = w.topics;
                    return `
                            <div class="webinar-card">
                                <h1>${w.title || 'Webinar'}</h1>
                                <div class="webinar-meta">${dateStr}</div>
                                ${level ? `<div class="webinar-meta">Level: ${level}</div>` : ''}
                                ${seats ? `<div class="webinar-meta">${seats}</div>` : ''}
                                ${paid ? `<div class="webinar-meta">${paid}</div>` : ''}
                                ${desc ? `<div class="webinar-description">${desc}</div>` : ''}
                                <button class="register-btn">Register</button>
                            </div>
                        `;
                }).join('')}
                        <button class="glow-btn">All Webinars</button>`;
        } catch (e) { console.warn('loadWebinars failed', e); }
}

async function loadTestimonials() {
        try {
                const res = await fetch('/api/testimonials');
                if (!res.ok) return;
                const tests = await res.json();
                const wrapper = document.querySelector('.slides-wrapper-tests');
                const indicators = document.querySelector('.indicators');
                if (!wrapper || !Array.isArray(tests)) return;
                // Build slides using flexible field names from admin data
                wrapper.innerHTML = tests.map((t, idx) => {
                    const message = t.message || t.quote || t.text || t.review || '';
                    const name = t.name || t.author || t.person || '';
                    const role = t.role || t.title || '';
                    const org = t.org || t.organization || '';
                    const avatar = t.avatar || t.image || t.photo || '';
                    const avatarHtml = avatar ? `<img src="${avatar}" alt="${name || 'avatar'}" class="testimonial-avatar"/>` : `<div class="avatar-container"><div class="avatar-icon"></div><div class="avatar-body"></div></div>`;
                    return `
                        <div class="slide-tests ${idx===0? 'active':''}" data-index="${idx}">
                            <div class="testimonial-card">
                                ${avatar ? `<div class="avatar-wrap">${avatarHtml}</div>` : avatarHtml}
                                <div class="quote">"${message}"</div>
                                <div class="attribution">
                                    <div class="name">\u2014 ${name || (t.author || 'Anonymous')},</div>
                                    <div class="title">${role || org || ''}</div>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');

                // Build indicators
                if (indicators) {
                    indicators.innerHTML = tests.map((_, i) => `<button class="indicator" data-slide-tests="${i}" aria-label="Go to slide-tests ${i+1}"></button>`).join('');
                }

                // Cache nodes and wire interactions
                testSlides = wrapper.querySelectorAll('.slide-tests');
                testIndicators = indicators ? indicators.querySelectorAll('.indicator') : [];
                testCurrent = 0;

                // Set initial active classes
                testSlides.forEach((s, i) => s.classList.toggle('active', i === 0));
                if (testIndicators.length) testIndicators.forEach((ind, i) => {
                    ind.classList.toggle('active', i === 0);
                    ind.onclick = () => goToTestSlide(i);
                });
                // ensure auto-start only if there are slides
                if (testSlides && testSlides.length) {
                    // reset any running timer
                    stopTestAuto();
                    startTestAuto();
                }
        } catch (e) { console.warn('loadTestimonials failed', e); }
}

// Switch testimonial slide by index
function goToTestSlide(index) {
    if (!testSlides || testSlides.length === 0) return;
    const idx = ((index % testSlides.length) + testSlides.length) % testSlides.length;
    // update slides
    testSlides.forEach((s, i) => s.classList.toggle('active', i === idx));
    // update indicators
    if (testIndicators && testIndicators.length) testIndicators.forEach((d, i) => d.classList.toggle('active', i === idx));
    testCurrent = idx;
}

async function initFrontend() {
        await Promise.all([loadPrograms(), loadKits(), loadWebinars(), loadTestimonials()]);
        // Start sliders after data is loaded
        updateMainSlider();
        startMainAuto();
        startTestAuto();
    // Ensure wrapper height is correct after sliders start
    setTimeout(() => adjustMainSliderHeight(), 50);
}

// Kick off
initFrontend();

// Periodically refresh frontend data so admin changes appear without a full page reload
const REFRESH_INTERVAL_MS = 20000; // 20 seconds
setInterval(async () => {
    await Promise.all([loadPrograms(), loadKits(), loadWebinars(), loadTestimonials()]);
}, REFRESH_INTERVAL_MS);
