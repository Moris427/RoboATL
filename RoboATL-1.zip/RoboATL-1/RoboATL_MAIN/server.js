const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const session = require('express-session');
const dotenv = require('dotenv');
dotenv.config();
const app = express();
const PORT = process.env.PORT || 4000;
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  name: 'admin.sid',
  secret: process.env.SESSION_SECRET || 'change_this_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 1000*60*60 }
}));
// Serve the RoboATL frontend at the site root
app.use(express.static(path.join(__dirname, 'RoboATL-main')));

// Keep the existing `public` folder for the admin UI or other legacy assets
app.use('/public', express.static(path.join(__dirname, 'public')));
// Expose the admin panel at paths it expects so the admin HTML can use absolute
// paths like `/admin.js`. Keep these explicit routes before the catch-all below.
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});
app.get('/admin.js', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.js'));
});
function loadJSON(file) {
  const filePath = path.join(__dirname, 'data', file);
  if (!fs.existsSync(filePath)) return [];
  const raw = fs.readFileSync(filePath, 'utf8');
  try { return JSON.parse(raw); } catch (e) { return []; }
}
function saveJSON(file, data) {
  fs.writeFileSync(path.join(__dirname, 'data', file), JSON.stringify(data, null, 2));
}
function createGetRoute(endpoint, filename) {
  app.get(`/api/${endpoint}`, (req, res) => {
    try { const data = loadJSON(filename); res.json(data); } catch (err) { res.status(500).json({ error: 'Server error' }); }
  });
}
function createPostRoute(endpoint, filename) {
  app.post(`/api/${endpoint}`, (req, res) => {
    try {
      const data = loadJSON(filename);
      const newItem = { id: Date.now(), ...req.body };
      data.push(newItem);
      saveJSON(filename, data);
      res.status(201).json(newItem);
    } catch (err) {
      res.status(500).json({ error: 'Server error' });
    }
  });

  // Edit (PUT)
  app.put(`/api/${endpoint}/:id`, (req, res) => {
    try {
      const data = loadJSON(filename);
      const idx = data.findIndex(item => String(item.id) === String(req.params.id));
      if (idx === -1) return res.status(404).json({ error: 'Not found' });
      data[idx] = { ...data[idx], ...req.body };
      saveJSON(filename, data);
      res.json(data[idx]);
    } catch (err) {
      res.status(500).json({ error: 'Server error' });
    }
  });

  // Delete (DELETE)
  app.delete(`/api/${endpoint}/:id`, (req, res) => {
    try {
      let data = loadJSON(filename);
      const idx = data.findIndex(item => String(item.id) === String(req.params.id));
      if (idx === -1) return res.status(404).json({ error: 'Not found' });
      const deleted = data[idx];
      data.splice(idx, 1);
      saveJSON(filename, data);
      res.json(deleted);
    } catch (err) {
      res.status(500).json({ error: 'Server error' });
    }
  });
}
createGetRoute('programs','programs.json');
createPostRoute('programs','programs.json');
createGetRoute('webinars','webinars.json');
createPostRoute('webinars','webinars.json');
createGetRoute('kits','kits.json');
createPostRoute('kits','kits.json');
createGetRoute('posts','posts.json');
createPostRoute('posts','posts.json');
createGetRoute('testimonials','testimonials.json');
createPostRoute('testimonials','testimonials.json');
createGetRoute('users','users.json');
createPostRoute('users','users.json');
createGetRoute('inquiries','inquiries.json');
createPostRoute('inquiries','inquiries.json');
function ensureAdmin(req, res, next) { if (req.session && req.session.isAdmin) return next(); return res.status(401).json({ error: 'Unauthorized' }); }
app.post('/admin/login', (req, res) => { const { password } = req.body; const adminPass = process.env.ADMIN_PASSWORD || 'roboAtl@427'; if (password === adminPass) { req.session.isAdmin = true; return res.json({ ok: true }); } else { return res.status(401).json({ error: 'Invalid password' }); } });
app.post('/admin/logout', (req, res) => { req.session.destroy(err => { res.clearCookie('admin.sid'); return res.json({ ok: true }); }); });
app.get('/admin/data', ensureAdmin, (req, res) => {
  try {
    const files = ['programs.json','webinars.json','kits.json','posts.json','testimonials.json','users.json','inquiries.json'];
    const payload = {};
    files.forEach(f => { const key = f.replace('.json',''); payload[key] = loadJSON(f); });
    res.json(payload);
  } catch (err) { res.status(500).json({ error: 'Server error' }); }
});
app.post('/admin/save/:file', ensureAdmin, (req, res) => {
  const fileParam = req.params.file; const allowed = ['programs','webinars','kits','posts','testimonials','users'];
  if (!allowed.includes(fileParam)) return res.status(400).json({ error: 'Invalid file' });
  // Main server file for admin panel and API
  const filename = `${fileParam}.json`; const data = req.body.data;
  try { saveJSON(filename, data); return res.json({ ok: true }); } catch (err) { return res.status(500).json({ error: 'Save failed' }); }
  // File system for reading/writing JSON data
});
  // Path for file/directory operations
// For any non-API route, serve the RoboATL frontend index.html so client-side routing works
app.get('*', (req, res) => {
  // If the request is for API or admin endpoints, let those routes handle it (they're defined above).
  // Otherwise send the frontend's index.html
  res.sendFile(path.join(__dirname, 'RoboATL-main', 'index.html'));
});
  // CORS for cross-origin requests
app.listen(PORT, () => { console.log(`Server running at http://localhost:${PORT}`); });
  // Session for admin authentication

  // Dotenv for environment variables
