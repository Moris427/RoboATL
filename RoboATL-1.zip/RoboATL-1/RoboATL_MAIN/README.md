Express + JSON backend + Static frontend (Tailwind)
-------------------------------------------------
How to run:
1. Copy this folder to your machine (or run here).
2. Install dependencies: npm install
3. Create .env from .env.example and set ADMIN_PASSWORD if you want.
4. Start server: npm start
5. Open http://localhost:4000/
Admin panel: http://localhost:4000/admin.html (use ADMIN_PASSWORD)
