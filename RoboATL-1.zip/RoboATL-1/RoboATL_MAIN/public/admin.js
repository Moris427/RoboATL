// POST request helper (login, logout, etc.)
async function postJSON(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  return res;
}
// Admin login
async function login(password) {
  const res = await postJSON('/admin/login', { password });
  return res.ok;
}
// Admin logout
async function logout() {
  await postJSON('/admin/logout', {});
  window.location.reload();
}
// JSON pretty print for display
function prettyJSON(obj) { return JSON.stringify(obj, null, 2); }
function makeBlock(title, key, data) {
  const wrapper = document.createElement('div');
  wrapper.className = 'bg-white p-4 rounded shadow';
  const h = document.createElement('h3');
  h.className = 'font-semibold mb-2';
  h.textContent = title;
  wrapper.appendChild(h);

  // Main block renderer for each section in admin panel
  // Inquiries section (read-only, grouped by type)
  // Inquiries section: grouped by type (program/kit/webinar), read-only
  if (key === 'inquiries' && Array.isArray(data)) {
    if (data.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'text-gray-400 italic';
      empty.textContent = 'No inquiries yet.';
      wrapper.appendChild(empty);
    } else {
      // Group by type (program, kit, webinar)
      const groups = { program: [], kit: [], webinar: [] };
      data.forEach(item => {
        if (item.type === 'program') groups.program.push(item);
        else if (item.type === 'kit') groups.kit.push(item);
        else if (item.type === 'webinar') groups.webinar.push(item);
      });
      let anyShown = false;
      Object.entries(groups).forEach(([type, items]) => {
        if (items.length === 0) return;
        anyShown = true;
        const section = document.createElement('div');
        section.className = 'mb-6';
        const sectionTitle = document.createElement('h4');
        sectionTitle.className = 'text-lg font-bold mb-2';
        sectionTitle.textContent = type.charAt(0).toUpperCase() + type.slice(1) + ' Inquiries';
        section.appendChild(sectionTitle);
        const grid = document.createElement('div');
        grid.className = 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4';
        items.forEach(item => {
          const card = document.createElement('div');
          card.className = 'border rounded p-3 bg-gray-50 shadow-sm';
          Object.keys(item).forEach(k => {
            if (k === 'type') return;
            const row = document.createElement('div');
            row.className = 'mb-1';
            const label = document.createElement('span');
            label.className = 'font-semibold';
            label.textContent = k + ': ';
            const value = document.createElement('span');
            value.textContent = Array.isArray(item[k]) ? item[k].join(', ') : item[k];
            row.appendChild(label);
            row.appendChild(value);
            card.appendChild(row);
          });
          grid.appendChild(card);
        });
        section.appendChild(grid);
        wrapper.appendChild(section);
      });
      if (!anyShown) {
        const empty = document.createElement('div');
        empty.className = 'text-gray-400 italic';
        empty.textContent = 'No inquiries yet.';
        wrapper.appendChild(empty);
      }
    }
    return wrapper;
  }

  // Generic add/edit/delete UI for all main sections
  // Editable sections: programs, kits, webinars, posts, testimonials
  const editableKeys = ['programs', 'kits', 'webinars', 'posts', 'testimonials'];
  if (editableKeys.includes(key) && Array.isArray(data)) {
    // Add button
  // Add button for each editable section
  const addBtn = document.createElement('button');
    addBtn.className = 'mb-4 bg-green-600 text-white px-3 py-1 rounded';
    addBtn.textContent = `+ Add ${title.slice(0, -1)}`;
    addBtn.onclick = () => showItemForm(key);
    wrapper.appendChild(addBtn);

  // Show message if no data
  if (data.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'text-gray-400 italic';
      empty.textContent = 'No data available.';
      wrapper.appendChild(empty);
    } else {
  // Cards grid for all items
  const grid = document.createElement('div');
      grid.className = 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4';
      data.forEach(item => {
        const card = document.createElement('div');
        card.className = 'border rounded p-3 bg-gray-50 shadow-sm flex flex-col';
  // Show all fields in card
  Object.keys(item).forEach(k => {
          const row = document.createElement('div');
          row.className = 'mb-1';
          const label = document.createElement('span');
          label.className = 'font-semibold';
          label.textContent = k + ': ';
          const value = document.createElement('span');
          value.textContent = Array.isArray(item[k]) ? item[k].join(', ') : item[k];
          row.appendChild(label);
          row.appendChild(value);
          card.appendChild(row);
        });
  // Edit/Delete buttons for each card
        const btnRow = document.createElement('div');
        btnRow.className = 'mt-2 flex gap-2';
        const editBtn = document.createElement('button');
        editBtn.className = 'bg-blue-500 text-white px-2 py-1 rounded text-xs';
        editBtn.textContent = 'Edit';
        editBtn.onclick = () => showItemForm(key, item);
        const delBtn = document.createElement('button');
        delBtn.className = 'bg-red-500 text-white px-2 py-1 rounded text-xs';
        delBtn.textContent = 'Delete';
        delBtn.onclick = () => deleteItem(key, item.id);
        btnRow.appendChild(editBtn);
        btnRow.appendChild(delBtn);
        card.appendChild(btnRow);
        grid.appendChild(card);
      });
      wrapper.appendChild(grid);
    }
  } else {
    const pre = document.createElement('pre');
    pre.className = 'overflow-auto max-h-64 p-2 bg-gray-100 rounded text-sm';
    pre.textContent = prettyJSON(data);
    wrapper.appendChild(pre);
  }
  return wrapper;
}

// Show add/edit modal form for all editable sections
function showItemForm(key, item = null) {
  // Remove any existing modal
  // Remove any existing modal before opening new
  const oldModal = document.getElementById('itemFormModal');
  if (oldModal) oldModal.remove();

  // Modal overlay
  const modal = document.createElement('div');
  modal.id = 'itemFormModal';
  modal.className = 'fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50';
  modal.style.zIndex = 1000;

  // Modal form box
  const formBox = document.createElement('div');
  formBox.className = 'bg-white p-6 rounded shadow max-w-lg w-full max-h-[90vh] overflow-y-auto';
  const isEdit = !!item;
  // Section-specific form fields
  let formFields = '';
  // Section-specific fields
  // Programs form fields
  if (key === 'programs') {
    formFields = `
      <div><label class="block">Title<input name="title" class="w-full border p-2 rounded" value="${item?.title || ''}" required /></label></div>
      <div><label class="block">Level<input name="level" class="w-full border p-2 rounded" value="${item?.level || ''}" required /></label></div>
      <div><label class="block">Description<textarea name="description" class="w-full border p-2 rounded">${item?.description || ''}</textarea></label></div>
  <div>
    <label class="block">Contents
      <div id="contentsList" class="mt-2 space-y-2"></div>
      <div class="mt-2"><button type="button" id="addContentBtn" class="bg-gray-200 px-3 py-1 rounded">+ Add content</button></div>
    </label>
  </div>
      <div><label class="block">Audience (comma separated)<input name="audience" class="w-full border p-2 rounded" value="${item?.audience ? item.audience.join(', ') : ''}" /></label></div>
      <div><label class="block">Duration (weeks)<input name="durationWeeks" type="number" class="w-full border p-2 rounded" value="${item?.durationWeeks || ''}" /></label></div>
      <div><label class="block">Mode (comma separated)<input name="mode" class="w-full border p-2 rounded" value="${item?.mode ? item.mode.join(', ') : ''}" /></label></div>
      <div><label class="block">Outcomes (comma separated)<input name="outcomes" class="w-full border p-2 rounded" value="${item?.outcomes ? item.outcomes.join(', ') : ''}" /></label></div>
      <div><label class="block">Price (INR)<input name="priceINR" type="number" class="w-full border p-2 rounded" value="${item?.priceINR || ''}" /></label></div>
      <div><label class="block">Badge<input name="badge" class="w-full border p-2 rounded" value="${item?.badge || ''}" /></label></div>
      <div><label class="block">Syllabus (comma separated)<input name="syllabus" class="w-full border p-2 rounded" value="${item?.syllabus ? item.syllabus.join(', ') : ''}" /></label></div>
    `;
  // Kits form fields
  } else if (key === 'kits') {
    formFields = `
      <div><label class="block">Name<input name="name" class="w-full border p-2 rounded" value="${item?.name || ''}" required /></label></div>
      <div><label class="block">Description<textarea name="description" class="w-full border p-2 rounded">${item?.description || ''}</textarea></label></div>
      <div><label class="block">Contents (comma separated)<input name="contents" class="w-full border p-2 rounded" value="${item?.contents ? item.contents.join(', ') : ''}" /></label></div>
      <div><label class="block">Price (INR)<input name="priceINR" type="number" class="w-full border p-2 rounded" value="${item?.priceINR || ''}" /></label></div>
      <div><label class="block">Image URL<input name="image" class="w-full border p-2 rounded" value="${item?.image || ''}" /></label></div>
    `;
  // Webinars form fields
  } else if (key === 'webinars') {
    formFields = `
      <div><label class="block">Title<input name="title" class="w-full border p-2 rounded" value="${item?.title || ''}" required /></label></div>
      <div><label class="block">Date<input name="date" type="date" class="w-full border p-2 rounded" value="${item?.date || ''}" /></label></div>
      <div><label class="block">Speaker<input name="speaker" class="w-full border p-2 rounded" value="${item?.speaker || ''}" /></label></div>
      <div><label class="block">Description<textarea name="description" class="w-full border p-2 rounded">${item?.description || ''}</textarea></label></div>
      <div><label class="block">Tags (comma separated)<input name="tags" class="w-full border p-2 rounded" value="${item?.tags ? item.tags.join(', ') : ''}" /></label></div>
    `;
  // Posts form fields
  } else if (key === 'posts') {
    formFields = `
      <div><label class="block">Title<input name="title" class="w-full border p-2 rounded" value="${item?.title || ''}" required /></label></div>
      <div><label class="block">Content<textarea name="content" class="w-full border p-2 rounded">${item?.content || ''}</textarea></label></div>
      <div><label class="block">Author<input name="author" class="w-full border p-2 rounded" value="${item?.author || ''}" /></label></div>
      <div><label class="block">Tags (comma separated)<input name="tags" class="w-full border p-2 rounded" value="${item?.tags ? item.tags.join(', ') : ''}" /></label></div>
    `;
  // Testimonials form fields
  } else if (key === 'testimonials') {
    formFields = `
      <div><label class="block">Name<input name="name" class="w-full border p-2 rounded" value="${item?.name || ''}" required /></label></div>
      <div><label class="block">Message<textarea name="message" class="w-full border p-2 rounded">${item?.message || ''}</textarea></label></div>
      <div><label class="block">Role<input name="role" class="w-full border p-2 rounded" value="${item?.role || ''}" /></label></div>
      <div><label class="block">Avatar URL (optional)<input name="avatar" class="w-full border p-2 rounded" value="${item?.avatar || ''}" /></label></div>
    `;
  }
  formBox.innerHTML = `
    <h2 class="text-xl font-bold mb-4">${isEdit ? 'Edit' : 'Add'} ${key.slice(0, -1).charAt(0).toUpperCase() + key.slice(1, -1)}</h2>
    <form id="itemForm" class="space-y-3">
      <input type="hidden" name="id" value="${item?.id || ''}" />
      ${formFields}
      <div class="flex gap-2 mt-4">
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">${isEdit ? 'Update' : 'Add'}</button>
        <button type="button" id="cancelBtn" class="bg-gray-300 px-4 py-2 rounded">Cancel</button>
      </div>
    </form>
  `;
  modal.appendChild(formBox);
  document.body.appendChild(modal);

  // Cancel button closes modal
  document.getElementById('cancelBtn').onclick = () => { modal.remove(); };
  // Initialize dynamic contents list for programs
  if (key === 'programs') {
    const contentsList = document.getElementById('contentsList');
    const addBtn = document.getElementById('addContentBtn');
    // helper to create an input row
    function makeRow(value = '') {
      const row = document.createElement('div');
      row.className = 'flex gap-2';
      const inp = document.createElement('input');
      inp.type = 'text';
      inp.className = 'flex-1 border p-2 rounded';
      inp.value = value;
      const rem = document.createElement('button');
      rem.type = 'button';
      rem.className = 'bg-red-500 text-white px-2 rounded';
      rem.textContent = 'Remove';
      rem.addEventListener('click', () => row.remove());
      row.appendChild(inp);
      row.appendChild(rem);
      return row;
    }
    // populate with existing contents
    const existing = item?.contents || [];
    if (existing.length) existing.forEach(c => contentsList.appendChild(makeRow(c)));
    else contentsList.appendChild(makeRow(''));
    addBtn.addEventListener('click', () => contentsList.appendChild(makeRow('')));
  }
  // Form submit handler (add/edit)
  document.getElementById('itemForm').onsubmit = async (e) => {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    let payload = {};
    if (key === 'programs') {
      // collect dynamic contents from the modal DOM
      const contentsInputs = Array.from(document.querySelectorAll('#contentsList input'));
      const contentsArr = contentsInputs.map(i => i.value.trim()).filter(Boolean);
      payload = {
        title: formData.get('title'),
        description: formData.get('description'),
        contents: contentsArr,
        level: formData.get('level'),
        audience: formData.get('audience').split(',').map(s => s.trim()).filter(Boolean),
        durationWeeks: Number(formData.get('durationWeeks')),
        mode: formData.get('mode').split(',').map(s => s.trim()).filter(Boolean),
        outcomes: formData.get('outcomes').split(',').map(s => s.trim()).filter(Boolean),
        priceINR: Number(formData.get('priceINR')),
        badge: formData.get('badge'),
        syllabus: formData.get('syllabus').split(',').map(s => s.trim()).filter(Boolean)
      };
    } else if (key === 'kits') {
      payload = {
        name: formData.get('name'),
        description: formData.get('description'),
        contents: formData.get('contents').split(',').map(s => s.trim()).filter(Boolean),
        priceINR: Number(formData.get('priceINR')),
        image: formData.get('image')
      };
    } else if (key === 'webinars') {
      payload = {
        title: formData.get('title'),
        date: formData.get('date'),
        speaker: formData.get('speaker'),
        description: formData.get('description'),
        tags: formData.get('tags').split(',').map(s => s.trim()).filter(Boolean)
      };
    } else if (key === 'posts') {
      payload = {
        title: formData.get('title'),
        content: formData.get('content'),
        author: formData.get('author'),
        tags: formData.get('tags').split(',').map(s => s.trim()).filter(Boolean)
      };
    } else if (key === 'testimonials') {
      payload = {
        name: formData.get('name'),
        message: formData.get('message'),
        role: formData.get('role')
        ,avatar: formData.get('avatar') || ''
      };
    }
  // Edit or Add API call
  if (isEdit) {
      await fetch(`/api/${key}/${item.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } else {
      await fetch(`/api/${key}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    }
  // Close modal and reload data
  modal.remove();
  await loadAdminData();
  };
}

// Delete item from editable section
async function deleteItem(key, id) {
  if (!confirm('Are you sure you want to delete this item?')) return;
  await fetch(`/api/${key}/${id}`, { method: 'DELETE' });
  await loadAdminData();
}

// (Legacy) Delete program (not used, use deleteItem)
async function deleteProgram(id) {
  if (!confirm('Are you sure you want to delete this program?')) return;
  await fetch(`/api/programs/${id}`, { method: 'DELETE' });
  await loadAdminData();
}
// Load all admin data and render all sections
async function loadAdminData() {
  const res = await fetch('/admin/data');
  if (!res.ok) {
    if (res.status === 401) { document.getElementById('adminPanel').classList.add('hidden'); document.getElementById('loginBox').classList.remove('hidden'); }
    return;
  }
  const json = await res.json();
  const container = document.getElementById('dataContainer'); container.innerHTML = '';
  Object.keys(json).forEach(key => { const title = key.charAt(0).toUpperCase() + key.slice(1); container.appendChild(makeBlock(title, key, json[key])); });
}
// Login button handler
document.getElementById('loginBtn').addEventListener('click', async () => {
  const pass = document.getElementById('adminPassword').value; document.getElementById('loginError').classList.add('hidden');
  const ok = await login(pass);
  if (ok) { document.getElementById('loginBox').classList.add('hidden'); document.getElementById('adminPanel').classList.remove('hidden'); loadAdminData(); } else { const err = document.getElementById('loginError'); err.textContent = 'Invalid password'; err.classList.remove('hidden'); }
});
// Logout button handler
document.getElementById('logoutBtn').addEventListener('click', async () => { await logout(); });
// Refresh data button handler
document.getElementById('refreshBtn').addEventListener('click', async () => { await loadAdminData(); });
