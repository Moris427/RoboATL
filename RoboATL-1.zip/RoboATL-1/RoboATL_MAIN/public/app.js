// Render a list of items into a container using a template function
function render(containerId, items, templateFn) {
  const el = document.getElementById(containerId);
  if(!el) return;
  el.innerHTML = items.map(templateFn).join('');
}
// Load and render all programs
async function loadPrograms() {
  const res = await fetch('/api/programs');
  const programs = await res.json();
  render('programs-container', programs, p => `<div class="p-4 bg-white shadow rounded"><h3 class="font-semibold text-lg">${p.title}</h3><p class="text-sm text-gray-600">${p.description || ''}</p></div>`);
}

// Load and render all webinars
async function loadWebinars() {
  const res = await fetch('/api/webinars');
  const webinars = await res.json();
  render('webinars-container', webinars, w => `<div class="p-4 bg-white shadow rounded"><h3 class="font-semibold">${w.title}</h3><p class="text-sm text-gray-600">Date: ${w.date || ''}</p></div>`);
}

// Load and render all kits
async function loadKits() {
  const res = await fetch('/api/kits');
  const kits = await res.json();
  render('kits-container', kits, k => `<div class="p-4 bg-white shadow rounded"><h3 class="font-semibold text-lg">${k.name}</h3><p class="text-sm text-gray-600">${k.description || ''}</p></div>`);
}

// Load and render all blog posts
async function loadBlog() {
  const res = await fetch('/api/posts');
  const posts = await res.json();
  render('blog-container', posts, b => `<div class="p-4 bg-white shadow rounded"><h3 class="font-semibold text-lg">${b.title}</h3><p class="text-sm text-gray-600">${b.excerpt || ''}</p></div>`);
}

// Load and render all testimonials
async function loadTestimonials() {
  const res = await fetch('/api/testimonials');
  const testimonials = await res.json();
  render('testimonials-container', testimonials, t => `<div class="p-4 bg-white shadow rounded"><p class="italic">"${t.message}"</p><p class="mt-2 font-semibold">- ${t.author || 'Anonymous'}</p></div>`);
}

// Initial load for all sections
loadPrograms();
loadWebinars();
loadKits();
loadBlog();
loadTestimonials();
