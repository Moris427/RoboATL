async function loadPrograms() {
  const res = await fetch('/api/programs');
  const data = await res.json();
  const container = document.getElementById('programsContainer');
  container.innerHTML = '';
  data.forEach(program => {
    const card = document.createElement('div');
    card.className = 'bg-white rounded shadow p-5 flex flex-col';
    card.innerHTML = `
      <div class="flex items-center justify-between mb-2">
        <h2 class="text-xl font-bold">${program.title}</h2>
        ${program.badge ? `<span class="bg-yellow-200 text-yellow-800 text-xs px-2 py-1 rounded">${program.badge}</span>` : ''}
      </div>
      <div class="text-sm text-gray-500 mb-2">Level: <span class="font-semibold">${program.level}</span></div>
      <div class="mb-2"><span class="font-semibold">Audience:</span> ${program.audience.join(', ')}</div>
      <div class="mb-2"><span class="font-semibold">Duration:</span> ${program.durationWeeks} weeks</div>
      <div class="mb-2"><span class="font-semibold">Mode:</span> ${program.mode.join(', ')}</div>
      <div class="mb-2"><span class="font-semibold">Price:</span> ₹${program.priceINR}</div>
      <div class="mb-2"><span class="font-semibold">Outcomes:</span>
        <ul class="list-disc list-inside text-gray-700">
          ${program.outcomes.map(o => `<li>${o}</li>`).join('')}
        </ul>
      </div>
      <div class="mb-2"><span class="font-semibold">Syllabus:</span>
        <ul class="list-disc list-inside text-gray-700">
          ${program.syllabus.map(s => `<li>${s}</li>`).join('')}
        </ul>
      </div>
    `;
    container.appendChild(card);
  });
}

window.addEventListener('DOMContentLoaded', loadPrograms);
